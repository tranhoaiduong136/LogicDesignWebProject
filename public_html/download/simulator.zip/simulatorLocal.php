<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Aldrich&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
	<script src="../js/myscripts.js"></script>
    <title>Logic Design Project</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light sticky-top bg-light">
        <div class="container-fluid px-4 px-lg-5 justify-center">
            <a class="navbar-brand text-success" style="font-family: Aldrich, sans-serif;">MIPS for everyone</a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ms-auto my-2 my-lg-0">
                <li class="nav-item"><a class="nav-link">Home</a></li>
                <li class="nav-item"><a class="nav-link">Tool</a></li>
            </ul>
            </div>
        </div>
    </nav>

    <section class="container-fluid mb-5">
        <div class="my-3 mx-5 d-flex justify-content-between">
            <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">Home</li>
                    <li class="breadcrumb-item">Tool</li>
                    <li class="breadcrumb-item active" aria-current="page">MIPS Simulator</li>
                </ol>
            </nav>
        </div>

        <div class="d-flex flex-column justify-content-center text-center mx-5 px-5">
            <h1 id="tool-name">MIPS Simulator</h1>
        </div>

        <div class="container-fluid mb-5">
            <form name="coding" method="post" action="">
                <div class="form-group">
                    <div class="container mx-auto d-block">
                        <div class="form-group container mb-4">
                            <label for="Type" class="form-label h4 my-2">Choose a functionality:</label>
                            <select class="form-control" id="Type" name="Datatype">
                                <option disabled class="text-success">MIPS virtual machine</option>
                                <option value="vm" aria-describedby="vmHelp">Virtual machine (C++ implementation)</option>
                                <option disabled class="text-success">MIPS and machine code converter</option>
                                <option value="2_a">Machine Code to Assembly code</option>
                                <option value="a_2">Assembly code to Machine code</option>
                            </select>
                            <div id="vmHelp" class="form-text text-secondary">
                                Note: <br>
                                - The input syntax used in Virtual Machine (C++ implementation) is a bit different from standard MIPS code.
                                For more information, please refer to Section 3.5.1 of our report. <br>
                                - For the MIPS and machine code converter, address of J-type instruction is set to be equal 0x01 by default.
                                Besides, minor bugs / errors may occur when handling too complicated program and hex values can not be processed at this moment.
                            </div>
                        </div>
                        <div class="form-group container mb-4">
                            <label for="code" class="form-label h4 my-2">Give your input below:</label>
                            <textarea class="form-control" id="subject" name="content" rows="5" placeholder="Your input goes here..." aria-describedby="codeHelp"></textarea>
                            <div id="codeHelp" class="form-text text-primary">This is a required field!</div>
                        </div>
                        <div class="form-group container">
                            <input class="btn btn-secondary" type="submit" name="RefreshButton" value="Refresh">
                            <input class="btn btn-success" type="submit" name="runButton" value="Run">
                            <input class="btn btn-primary" type="submit" name="reportButton" value="Write result">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>

    <section class="container-fluid mx-auto">
        <div class="d-flex flex-column justify-content-center text-left">
            <div class="d-block mx-5 px-4">
                <?php
                    if ($_SERVER["REQUEST_METHOD"] == "POST"){
                        if (!file_exists("solution.txt") || !file_exists("code.txt")) {
                            exit("Error: File does not exist.");
                        }
                        if (isset($_POST['RefreshButton'])) {
                            file_put_contents("solution.txt","");
                            file_put_contents("code.txt", "");
                        }
                        if (isset($_POST['runButton']) && !empty($_POST['content'])) {
                            file_put_contents("solution.txt", "");
                            file_put_contents("code.txt", "");

                            $file = fopen("code.txt","a+");
                            while(!feof($file))
                            $old = fgets($file);

                            $text = $_POST["content"];
                            file_put_contents("code.txt", $old . $text);
                            fclose($file);

                            // Execute code here
                            if (isset($_POST['Datatype'])){
                                $data = $_POST['Datatype'];
                                echo "<p class='h5 py-3'><mark>Execution report</mark></p>";
                                echo "<p class='mt-2 mb-5 py-2 px-3 mx-auto border border-primary'>";
                                if ($data == '2_a') {
                                    echo shell_exec('binary_asm.exe');
                                } else if ($data == 'a_2') {
                                    echo shell_exec('asm_binary.exe');
                                }
                                else if ($data == 'vm'){
                                    echo shell_exec('single_VM.exe');
                                }
                                echo "</p>";
                            }
                        }
                        if (isset($_POST['reportButton'])){
                            echo "<p class='h5 py-3'><mark>Result</mark></p>";
                            echo "<p class='mt-2 mb-5 py-2 px-3 mx-auto border border-primary'>";
                            $file = fopen("solution.txt","r");
                            while(!feof($file)) {
                                echo fgets($file). "<br>";
                            }
                            fclose($file);
                            echo "</p>";
                        }
                    }
                ?>
            </div>
        </div>
    </section>

    <footer class="py-5" style="background-color: #2d6a4f;">
        <div class="container px-4 px-lg-5"><div class="small text-center text-light">Copyright &copy; 2021</div></div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
